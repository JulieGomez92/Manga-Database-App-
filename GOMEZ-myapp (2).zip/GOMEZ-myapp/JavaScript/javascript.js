/*Everything in this file is JavaScript*/
console.log("Hello, world!");

/*localStorage: save */
localStorage.setItem("entry1","Julie Gomez");
localStorage.setItem("entry-2","Carlos Gomez");
localStorage.setItem("dogname","Beckett Gomez");

localStorage.setItem("entry1", "OlympiaBaker");

//ls.save("firstname:julie", "lastname:gomez", "age:28", "favcolor:red");